package com.baidu.openrasp.v8;

public interface StackGetter {
  public byte[] get();
}