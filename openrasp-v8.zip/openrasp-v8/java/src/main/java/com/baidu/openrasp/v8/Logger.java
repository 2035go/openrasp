package com.baidu.openrasp.v8;

public interface Logger {
  public void log(String msg);
}